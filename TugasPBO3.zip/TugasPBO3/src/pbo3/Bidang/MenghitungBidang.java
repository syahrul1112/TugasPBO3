package pbo3.Bidang;

public interface MenghitungBidang {
    double Luas();
    double Keliling();
}
