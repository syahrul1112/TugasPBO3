package pbo3.Bidang;

public class Lingkaran implements MenghitungBidang{
      
    public int jarijari;
    
   public Lingkaran(int jarijari){

        this.jarijari = jarijari;
    }
    
    @Override
    public double Luas(){
        return Math.PI*jarijari*jarijari;
    }
    
    @Override
    public double Keliling(){
        return Math.PI*2*jarijari;
    }
}
