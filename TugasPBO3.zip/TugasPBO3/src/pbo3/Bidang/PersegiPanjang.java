package pbo3.Bidang;

public class PersegiPanjang implements MenghitungBidang{
      
   public int panjang;
   public int lebar;
    
  public PersegiPanjang(int panjang, int lebar){
        
        this.panjang = panjang;
        this.lebar = lebar;
    }
    
        @Override
        public double Luas(){
        return panjang*lebar;
    }
       
        @Override
        public double Keliling(){
        return 2*panjang+2*lebar;
    }
}
