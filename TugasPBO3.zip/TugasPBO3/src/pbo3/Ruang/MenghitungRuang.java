package pbo3.Ruang;

public interface MenghitungRuang {
    double Volume(); 
    double Luaspermukaan();       
}
